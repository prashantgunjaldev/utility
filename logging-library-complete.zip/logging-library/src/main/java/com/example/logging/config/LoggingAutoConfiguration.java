package com.example.logging.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.example.logging")
@ConditionalOnProperty(name = "logging.enabled", havingValue = "true", matchIfMissing = true)
public class LoggingAutoConfiguration {
}