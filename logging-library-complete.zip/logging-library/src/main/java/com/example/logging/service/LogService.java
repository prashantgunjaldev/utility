package com.example.logging.service;

import com.example.logging.entity.ApiLog;
import com.example.logging.repository.LogRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class LogService {

    private final LogRepository logRepository;

    public LogService(LogRepository logRepository) {
        this.logRepository = logRepository;
    }

    @Transactional
    public void saveLog(String method, String uri, int status, String requestBody, String responseBody) {
        ApiLog log = new ApiLog();
        log.setMethod(method);
        log.setUri(uri);
        log.setStatus(status);
        log.setRequestBody(requestBody);
        log.setResponseBody(responseBody);
        logRepository.save(log);
    }
}