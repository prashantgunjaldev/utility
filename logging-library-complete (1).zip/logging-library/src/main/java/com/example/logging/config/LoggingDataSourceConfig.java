package com.example.logging.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@Configuration
@ConditionalOnProperty(name = "logging.db.enabled", havingValue = "true")
public class LoggingDataSourceConfig {

    @Value("${logging.db.url:}")
    private String dbUrl;

    @Value("${logging.db.username:}")
    private String dbUsername;

    @Value("${logging.db.password:}")
    private String dbPassword;

    @Value("${logging.db.driver-class-name:org.postgresql.Driver}")
    private String dbDriver;

    @Bean
    public DataSource loggingDataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setUrl(dbUrl);
        dataSource.setUsername(dbUsername);
        dataSource.setPassword(dbPassword);
        dataSource.setDriverClassName(dbDriver);
        return dataSource;
    }
}