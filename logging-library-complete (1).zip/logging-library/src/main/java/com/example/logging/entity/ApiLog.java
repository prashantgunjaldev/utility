package com.example.logging.entity;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "#{logging.db.table-name}")
public class ApiLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String method;
    private String uri;
    private int status;

    @Column(columnDefinition = "TEXT")
    private String requestBody;

    @Column(columnDefinition = "TEXT")
    private String responseBody;

    private LocalDateTime timestamp = LocalDateTime.now();

    // Getters and Setters
}