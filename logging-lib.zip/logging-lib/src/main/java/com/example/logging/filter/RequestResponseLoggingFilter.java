package com.example.logging.filter;

import com.example.logging.service.LoggingService;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;

public class RequestResponseLoggingFilter implements Filter {

    private static final Logger logger = LoggerFactory.getLogger(RequestResponseLoggingFilter.class);
    private final LoggingService loggingService;

    public RequestResponseLoggingFilter(LoggingService loggingService) {
        this.loggingService = loggingService;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        if (request instanceof HttpServletRequest && response instanceof HttpServletResponse) {
            HttpServletRequest httpRequest = (HttpServletRequest) request;
            HttpServletResponse httpResponse = (HttpServletResponse) response;
            
            loggingService.logRequest(httpRequest);
            chain.doFilter(request, response);
            loggingService.logResponse(httpResponse);
        } else {
            chain.doFilter(request, response);
        }
    }
}
