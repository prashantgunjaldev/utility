package com.example.logging.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class LoggingService {

    private static final Logger logger = LoggerFactory.getLogger(LoggingService.class);

    public void logRequest(HttpServletRequest request) {
        logger.info("Incoming Request: {} {}", request.getMethod(), request.getRequestURI());
    }

    public void logResponse(HttpServletResponse response) {
        logger.info("Outgoing Response: Status {}", response.getStatus());
    }
}
