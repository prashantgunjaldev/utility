package com.example.logging.config;

import com.example.logging.filter.RequestResponseLoggingFilter;
import com.example.logging.service.LoggingService;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LoggingAutoConfig {

    @Bean
    @ConditionalOnProperty(name = "logging.enabled", havingValue = "true", matchIfMissing = true)
    public LoggingService loggingService() {
        return new LoggingService();
    }

    @Bean
    @ConditionalOnProperty(name = "logging.enabled", havingValue = "true", matchIfMissing = true)
    public RequestResponseLoggingFilter loggingFilter(LoggingService loggingService) {
        return new RequestResponseLoggingFilter(loggingService);
    }
}
